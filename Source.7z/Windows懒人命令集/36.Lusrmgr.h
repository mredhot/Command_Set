#pragma once
#include "0.Command_Set.h"

class Lusrmgr : public Command_Set
{
public:
	Lusrmgr();
	void Command_Realize();
	~Lusrmgr();
};


