#pragma once
#include "0.Command_Set.h"

class Mmsys : public Command_Set
{
public:
	Mmsys();
	void Command_Realize();
	~Mmsys();
};


