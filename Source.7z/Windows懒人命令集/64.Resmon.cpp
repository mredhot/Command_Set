#include "64.Resmon.h"

Resmon::Resmon()
{
}

void Resmon::Command_Realize()
{
	system("Resmon");
	system("pause");
	system("cls");
}

Resmon::~Resmon()
{
}