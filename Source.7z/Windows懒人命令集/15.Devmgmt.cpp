#include "15.Devmgmt.h"

Devmgmt::Devmgmt()
{
}

void Devmgmt::Command_Realize()
{
	system("devmgmt.msc");
	system("pause");
	system("cls");
}

Devmgmt::~Devmgmt()
{
}