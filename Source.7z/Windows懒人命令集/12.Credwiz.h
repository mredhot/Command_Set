#pragma once
#include "0.Command_Set.h"

class Credwiz : public Command_Set
{
public:
	Credwiz();
	void Command_Realize();
	~Credwiz();
};

