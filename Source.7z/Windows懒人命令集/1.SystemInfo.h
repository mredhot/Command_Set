#pragma once
#include "0.Command_Set.h"


class System_Info : public Command_Set
{
public:
	System_Info();

	void Command_Realize();

	~System_Info();
};

