#include "81.Tree.h"

Tree::Tree()
{
}
void Tree::Command_Realize()
{
	system("Tree");
	system("pause");
	system("cls");
}



Tree::~Tree()
{
}