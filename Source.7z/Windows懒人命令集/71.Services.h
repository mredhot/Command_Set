#pragma once
#include "0.Command_Set.h"

class Services : public Command_Set
{
public:
	Services();
	void Command_Realize();
	~Services();
};


