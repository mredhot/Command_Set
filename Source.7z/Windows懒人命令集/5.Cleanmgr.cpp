#include "5.Cleanmgr.h"


Cleanmgr::Cleanmgr()
{
}
void Cleanmgr::Command_Realize()
{
	system("cleanmgr");
	system("pause");
	system("cls");
}
Cleanmgr::~Cleanmgr()
{
}