#include "65.Rstrui.h"

Rstrui::Rstrui()
{
}

void Rstrui::Command_Realize()
{
	system("Rstrui");
	system("pause");
	system("cls");
}


Rstrui::~Rstrui()
{
}