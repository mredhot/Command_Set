#include "58.Osk.h"

Osk::Osk()
{
}

void Osk::Command_Realize()
{
	system("osk");
	system("pause");
	system("cls");
}


Osk::~Osk()
{
}
