#include "1.SystemInfo.h"



System_Info::System_Info()
{
}

void System_Info::Command_Realize()
{
	system("systeminfo");
	system("pause");
	system("cls");
}


System_Info::~System_Info()
{
}