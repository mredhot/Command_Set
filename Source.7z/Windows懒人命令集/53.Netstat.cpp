#include "53.Netstat.h"

Netstat::Netstat()
{
}

void Netstat::Command_Realize()
{
	system("netstat");
	system("pause");
	system("cls");
}


Netstat::~Netstat()
{
}
