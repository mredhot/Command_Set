#include "74.Shrpubw.h"

Shrpubw::Shrpubw()
{
}

void Shrpubw::Command_Realize()
{
	system("shrpubw");
	system("pause");
	system("cls");
}

Shrpubw::~Shrpubw()
{
}
