#include "26.Firewall.h"

Firewall::Firewall()
{
}

void Firewall::Command_Realize()
{
	system("firewall.cpl");
	system("pause");
	system("cls");
}


Firewall::~Firewall()
{
}