#pragma once
#include "0.Command_Set.h"

class Rasphone : public Command_Set
{
public:
	Rasphone();
	void Command_Realize();
	~Rasphone();
};


