#include "9.Lock.h"

Lock::Lock()
{
}
void Lock::Command_Realize()
{
	system("rundll32 user32.dll,LockWorkStation");
	system("pause");
	system("cls");
}



Lock::~Lock()
{
}