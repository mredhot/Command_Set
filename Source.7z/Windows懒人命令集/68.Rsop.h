#pragma once
#include "0.Command_Set.h"

class Rsop : public Command_Set
{
public:
	Rsop();
	void Command_Realize();
	~Rsop();
};

