#include "4.Control.h"

Control::Control()
{
}

void Control::Command_Realize()
{
	system("control");
	system("pause");
	system("cls");
}




Control::~Control()
{
}