#include "46.Mspaint.h"

Mspaint::Mspaint()
{
}

void Mspaint::Command_Realize()
{
	system("mspaint");
	system("pause");
	system("cls");
}

Mspaint::~Mspaint()
{
}