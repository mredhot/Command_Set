#include "2.Ipconfig.h"

Ipconfig::Ipconfig()
{
}

void Ipconfig::Command_Realize()
{
	system("ipconfig");
	system("pause");
	system("cls");
}






Ipconfig::~Ipconfig()
{
}