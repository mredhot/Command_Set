#include "56.Odbcad32.h"

Odbcad32::Odbcad32()
{
}

void Odbcad32::Command_Realize()
{
	system("odbcad32");
	system("pause");
	system("cls");
}

Odbcad32::~Odbcad32()
{
}