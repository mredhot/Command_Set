#include "30.Hdwwiz.h"

Hdwwiz::Hdwwiz()
{
}

void Hdwwiz::Command_Realize()
{
	system("hdwwiz.cpl");
	system("pause");
	system("cls");
}


Hdwwiz::~Hdwwiz()
{
}
