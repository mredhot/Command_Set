#include "12.Credwiz.h"

Credwiz::Credwiz()
{
}
void Credwiz::Command_Realize()
{
	system("credwiz");
	system("pause");
	system("cls");
}



Credwiz::~Credwiz()
{
}