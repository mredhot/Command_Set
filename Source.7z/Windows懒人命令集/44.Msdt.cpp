#include "44.Msdt.h"

Msdt::Msdt()
{
}

void Msdt::Command_Realize()
{
	system("msdt");
	system("pause");
	system("cls");
}

Msdt::~Msdt()
{
}