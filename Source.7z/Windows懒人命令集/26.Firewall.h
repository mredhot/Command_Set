#pragma once
#include "0.Command_Set.h"

class Firewall : public Command_Set
{
public:
	Firewall();
	void Command_Realize();
	~Firewall();
};


