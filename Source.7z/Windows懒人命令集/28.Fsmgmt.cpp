#include "28.Fsmgmt.h"

Fsmgmt::Fsmgmt()
{
}

void Fsmgmt::Command_Realize()
{
	system("fsmgmt.msc");
	system("pause");
	system("cls");
}

Fsmgmt::~Fsmgmt()
{
}