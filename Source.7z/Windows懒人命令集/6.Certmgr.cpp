#include"6.Certmgr.h"


Certmgr::Certmgr()
{
}

void Certmgr::Command_Realize()
{
	system("certmgr.msc");
	system("pause");
	system("cls");
}



Certmgr::~Certmgr()
{
}