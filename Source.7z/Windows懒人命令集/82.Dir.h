#pragma once
#include "0.Command_Set.h"

class Dir : public Command_Set
{
public:
	Dir();
	void Command_Realize();
	~Dir();
};


