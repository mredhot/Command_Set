#include "47.Msra.h"


Msra::Msra()
{
}

void Msra::Command_Realize()
{
	system("Msra");
	system("pause");
	system("cls");
}

Msra::~Msra()
{
}