#include "10.Colorcpl.h"

Colorcpl::Colorcpl()
{
}

void Colorcpl::Command_Realize()
{
	system("colorcpl");
	system("pause");
	system("cls");
}

Colorcpl::~Colorcpl()
{
}