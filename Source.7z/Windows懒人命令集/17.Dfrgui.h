#pragma once
#include "0.Command_Set.h"

class Dfrgui : public Command_Set
{
public:
	Dfrgui();
	void Command_Realize();
	~Dfrgui();
};

