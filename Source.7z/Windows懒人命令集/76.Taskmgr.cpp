#include "76.Taskmgr.h"

Taskmgr::Taskmgr()
{
}

void Taskmgr::Command_Realize()
{
	system("taskmgr");
	system("pause");
	system("cls");
}

Taskmgr::~Taskmgr()
{
}
