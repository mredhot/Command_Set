#include "41.MdSched.h"

MdSched::MdSched()
{
}

void MdSched::Command_Realize()
{
	system("MdSched");
	system("pause");
	system("cls");
}

MdSched::~MdSched()
{
}