#include "13.Comexp.h"
Comexp::Comexp()
{
}
void Comexp::Command_Realize()
{
	system("comexp");
	system("pause");
	system("cls");
}



Comexp::~Comexp()
{
}