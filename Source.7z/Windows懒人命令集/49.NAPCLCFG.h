#pragma once
#include "0.Command_Set.h"

class NAPCLCFG : public Command_Set
{
public:
	NAPCLCFG();
	void Command_Realize();
	~NAPCLCFG();
};


