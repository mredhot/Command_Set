#include "22.Dxdiag.h"

Dxdiag::Dxdiag()
{
}

void Dxdiag::Command_Realize()
{
	system("dxdiag");
	system("pause");
	system("cls");
}

Dxdiag::~Dxdiag()
{
}