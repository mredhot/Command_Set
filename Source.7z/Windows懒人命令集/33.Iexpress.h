#pragma once
#include "0.Command_Set.h"

class Iexpress : public Command_Set
{
public:
	Iexpress();
	void Command_Realize();
	~Iexpress();
};


