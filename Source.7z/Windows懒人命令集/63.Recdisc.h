#pragma once
#include "0.Command_Set.h"

class Recdisc : public Command_Set
{
public:
	Recdisc();
	void Command_Realize();
	~Recdisc();
};


