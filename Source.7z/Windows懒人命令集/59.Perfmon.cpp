#include "59.Perfmon.h"

Perfmon::Perfmon()
{
}

void Perfmon::Command_Realize()
{
	system("perfmon");
	system("pause");
	system("cls");
}



Perfmon::~Perfmon()
{
}