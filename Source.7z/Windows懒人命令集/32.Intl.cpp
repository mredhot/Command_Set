#include "32.Intl.h"

Intl::Intl()
{
}

void Intl::Command_Realize()
{
	system("intl.cpl");
	system("pause");
	system("cls");
}

Intl::~Intl()
{
}
