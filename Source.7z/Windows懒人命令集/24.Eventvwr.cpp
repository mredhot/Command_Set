#include "24.Eventvwr.h"

Eventvwr::Eventvwr()
{
}

void Eventvwr::Command_Realize()
{
	system("eventvwr");
	system("pause");
	system("cls");
}


Eventvwr::~Eventvwr()
{
}