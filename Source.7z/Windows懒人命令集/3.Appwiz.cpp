#include "3.Appwiz.h"

Appwiz::Appwiz()
{
}

void Appwiz::Command_Realize()
{
	system("appwiz.cpl");
	system("pause");
	system("cls");
}

Appwiz::~Appwiz()
{
}