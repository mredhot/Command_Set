#include "60.Printmanagement.h"

Printmanagement::Printmanagement()
{
}
void Printmanagement::Command_Realize()
{
	system("printmanagement.msc");
	system("pause");
	system("cls");
}


Printmanagement::~Printmanagement()
{
}