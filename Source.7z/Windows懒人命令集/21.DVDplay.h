#pragma once
#include "0.Command_Set.h"

class DVDplay : public Command_Set
{
public:
	DVDplay();
	void Command_Realize();
	~DVDplay();
};


