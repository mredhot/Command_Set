#pragma once
#include "0.Command_Set.h"

class Winver : public Command_Set
{
public:
	Winver();
	void Command_Realize();
	~Winver();
};

