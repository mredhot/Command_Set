#include "7.Charmap.h"

Charmap::Charmap()
{
}

void Charmap::Command_Realize()
{
	system("charmap");
	system("pause");
	system("cls");
}

Charmap::~Charmap()
{
}
