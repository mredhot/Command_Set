#pragma once
#include "0.Command_Set.h"

class Devmgmt : public Command_Set
{
public:
	Devmgmt();
	void Command_Realize();
	~Devmgmt();
};

