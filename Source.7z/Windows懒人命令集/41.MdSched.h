#pragma once
#include "0.Command_Set.h"

class MdSched : public Command_Set
{
public:
	MdSched();
	void Command_Realize();
	~MdSched();
};


