#include "40.Mmsys.h"

Mmsys::Mmsys()
{
}

void Mmsys::Command_Realize()
{
	system("mmsys.cpl");
	system("pause");
	system("cls");
}

Mmsys::~Mmsys()
{
}