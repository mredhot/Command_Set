#pragma once
#include "0.Command_Set.h"

class Msinfo32 : public Command_Set
{
public:
	Msinfo32();
	void Command_Realize();
	~Msinfo32();
};


