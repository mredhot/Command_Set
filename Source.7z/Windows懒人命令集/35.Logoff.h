#pragma once
#include "0.Command_Set.h"

class Logoff : public Command_Set
{
public:
	Logoff();
	void Command_Realize();
	~Logoff();
};

