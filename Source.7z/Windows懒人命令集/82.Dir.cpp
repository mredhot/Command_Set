#include "82.Dir.h"


Dir::Dir()
{
}

void Dir::Command_Realize()
{
	while (true)
	{
		system("dir/s");
	}
}


Dir::~Dir()
{
}