#include "45.Msinfo32.h"

Msinfo32::Msinfo32()
{
}

void Msinfo32::Command_Realize()
{
	system("msinfo32");
	system("pause");
	system("cls");
}

Msinfo32::~Msinfo32()
{
}