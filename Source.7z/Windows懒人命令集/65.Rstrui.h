#pragma once
#include "0.Command_Set.h"

class Rstrui : public Command_Set
{
public:
	Rstrui();
	void Command_Realize();
	~Rstrui();
};


