#include "63.Recdisc.h"

Recdisc::Recdisc()
{
}

void Recdisc::Command_Realize()
{
	system("Recdisc");
	system("pause");
	system("cls");
}

Recdisc::~Recdisc()
{
}