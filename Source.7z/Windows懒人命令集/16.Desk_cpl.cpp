#include "16.Desk_cpl.h"

Desk_Cpl::Desk_Cpl()
{
}

void Desk_Cpl::Command_Realize()
{
	system("desk.cpl");
	system("pause");
	system("cls");
}

Desk_Cpl::~Desk_Cpl()
{
}