#pragma once
#include "0.Command_Set.h"

class Comexp : public Command_Set
{
public:
	Comexp();
	void Command_Realize();
	~Comexp();
};

