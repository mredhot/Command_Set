#pragma once
#include "0.Command_Set.h"

class Secpol : public Command_Set
{
public:
	Secpol();
	void Command_Realize();
	~Secpol();
};

