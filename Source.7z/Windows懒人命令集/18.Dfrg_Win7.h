#pragma once
#include "0.Command_Set.h"

class Dfrg_Win7 : public Command_Set
{
public:
	Dfrg_Win7();
	void Command_Realize();
	~Dfrg_Win7();
};


