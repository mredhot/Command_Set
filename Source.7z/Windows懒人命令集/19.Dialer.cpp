#include "19.Dialer.h"

Dialer::Dialer()
{
}

void Dialer::Command_Realize()
{
	system("dialer");
	system("pause");
	system("cls");
}

Dialer::~Dialer()
{
}