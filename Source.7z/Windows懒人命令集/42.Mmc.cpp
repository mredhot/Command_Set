#include "42.Mmc.h"

Mmc::Mmc()
{
}

void Mmc::Command_Realize()
{
	system("mmc");
	system("pause");
	system("cls");
}

Mmc::~Mmc()
{
}