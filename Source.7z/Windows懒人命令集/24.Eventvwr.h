#pragma once
#include "0.Command_Set.h"

class Eventvwr : public Command_Set
{
public:
	Eventvwr();
	void Command_Realize();
	~Eventvwr();
};


