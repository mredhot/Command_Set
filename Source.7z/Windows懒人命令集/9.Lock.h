#pragma once
#include "0.Command_Set.h"

class Lock: public Command_Set
{
public:
	Lock();
	void Command_Realize();
	~Lock();
};

