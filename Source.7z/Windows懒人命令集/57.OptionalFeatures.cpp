#include "57.OptionalFeatures.h"

OptionalFeatures::OptionalFeatures()
{
}

void OptionalFeatures::Command_Realize()
{
	system("OptionalFeatures");
	system("pause");
	system("cls");
}

OptionalFeatures::~OptionalFeatures()
{
}