#pragma once
#include "0.Command_Set.h"

class Mmc : public Command_Set
{
public:
	Mmc();
	void Command_Realize();
	~Mmc();
};


