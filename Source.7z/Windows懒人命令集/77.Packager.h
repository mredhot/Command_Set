#pragma once
#include "0.Command_Set.h"

class Packager : public Command_Set
{
public:
	Packager();
	void Command_Realize();
	~Packager();
};


