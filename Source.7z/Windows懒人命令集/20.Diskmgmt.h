#pragma once
#include "0.Command_Set.h"

class Diskmgmt : public Command_Set
{
public:
	Diskmgmt();
	void Command_Realize();
	~Diskmgmt();
};


