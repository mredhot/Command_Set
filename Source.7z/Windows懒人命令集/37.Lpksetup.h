#pragma once
#include "0.Command_Set.h"


class Lpksetup : public Command_Set
{
public:
	Lpksetup();
	void Command_Realize();
	~Lpksetup();
};


