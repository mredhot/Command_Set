#pragma once
#include "0.Command_Set.h"

class Notepad : public Command_Set
{
public:
	Notepad();
	void Command_Realize();
	~Notepad();
};


