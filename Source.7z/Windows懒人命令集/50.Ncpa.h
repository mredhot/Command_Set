#pragma once
#include "0.Command_Set.h"

class Ncpa : public Command_Set
{
public:
	Ncpa();
	void Command_Realize();
	~Ncpa();
};


