#include "62.Rasphone.h"

Rasphone::Rasphone()
{
}

void Rasphone::Command_Realize()
{
	system("Rasphone");
	system("pause");
	system("cls");
}

Rasphone::~Rasphone()
{
}