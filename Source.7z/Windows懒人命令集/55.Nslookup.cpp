#include "55.Nslookup.h"

Nslookup::Nslookup()
{
}

void Nslookup::Command_Realize()
{
	system("Nslookup");
	system("pause");
	system("cls");
}

Nslookup::~Nslookup()
{
}