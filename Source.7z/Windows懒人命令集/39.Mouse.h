#pragma once
#include "0.Command_Set.h"

class Mouse : public Command_Set
{
public:
	  Mouse();
	  void Command_Realize();
	 ~Mouse();
};


