#include "54.Notepad.h"


Notepad::Notepad()
{
}

void Notepad::Command_Realize()
{
	system("notepad");
	system("pause");
	system("cls");
}

Notepad::~Notepad()
{
}