#include "70.Secpol.h"

Secpol::Secpol()
{
}

void Secpol::Command_Realize()
{
	system("secpol.msc");
	system("pause");
	system("cls");
}

Secpol::~Secpol()
{
}
