#pragma once
#include "0.Command_Set.h"

class Nslookup : public Command_Set
{
public:
	Nslookup();
	void Command_Realize();
	~Nslookup();
};


