#pragma once
#include "0.Command_Set.h"

class Dxdiag :public Command_Set
{
public:
	Dxdiag();
	void Command_Realize();
	~Dxdiag();
};


