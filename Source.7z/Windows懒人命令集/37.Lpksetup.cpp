#include "37.Lpksetup.h"

Lpksetup::Lpksetup()
{
}

void Lpksetup::Command_Realize()
{
	system("lpksetup");
	system("pause");
	system("cls");
}

Lpksetup::~Lpksetup()
{
}