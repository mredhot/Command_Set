#pragma once
#include "0.Command_Set.h"

class Control : public Command_Set
{
public:
	Control();
	void Command_Realize();
	~Control();

};

