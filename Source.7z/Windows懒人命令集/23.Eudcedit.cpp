#include "23.Eudcedit.h"

Eudcedit::Eudcedit()
{
}

void Eudcedit::Command_Realize()
{
	system("eudcedit");
	system("pause");
	system("cls");
}



Eudcedit::~Eudcedit()
{
}