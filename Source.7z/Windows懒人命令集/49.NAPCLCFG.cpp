#include "49.NAPCLCFG.h"

NAPCLCFG::NAPCLCFG()
{
}

void NAPCLCFG::Command_Realize()
{
	system("NAPCLCFG.MSC");
	system("pause");
	system("cls");
}

NAPCLCFG::~NAPCLCFG()
{
}