#include "66.Regedit.h"

Regedit::Regedit()
{
}

void Regedit::Command_Realize()
{
	system("regedit.exe");
	system("pause");
	system("cls");
}



Regedit::~Regedit()
{
}