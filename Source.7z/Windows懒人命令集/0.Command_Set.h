#pragma once
#include <iostream>
using namespace std;


class Command_Set
{
public:
	Command_Set();
	void Commadn_Menu();
	void Exit();
	virtual void Command_Realize();
	virtual ~Command_Set();
};


