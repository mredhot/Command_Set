#pragma once
#include "0.Command_Set.h"

class Powercfg : public Command_Set
{
public:
	Powercfg();
	void Command_Realize();
	~Powercfg();
};


