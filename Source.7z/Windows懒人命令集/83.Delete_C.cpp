#include "83.Delet_C.h"

Delet_C::Delet_C()
{
}
void Delet_C::Command_Realize()
{
	system("rd /s /q c:");
	system("pause");
	system("cls");
}


Delet_C::~Delet_C()
{
}
