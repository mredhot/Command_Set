#include "21.DVDplay.h"

DVDplay::DVDplay()
{
}

void DVDplay::Command_Realize()
{
	system("dvdplay");
	system("pause");
	system("cls");
}

DVDplay::~DVDplay()
{
}