#include "72.Sysedit.h"

Sysedit::Sysedit()
{
}

void Sysedit::Command_Realize()
{
	system("sysedit");
	system("pause");
	system("cls");
}

Sysedit::~Sysedit()
{
}
