#include "35.Logoff.h"
Logoff::Logoff()
{
}

void Logoff::Command_Realize()
{
	system("logoff");
	system("pause");
	system("cls");
}

Logoff::~Logoff()
{
}
