#pragma once
#include "0.Command_Set.h"

class Mspaint : public Command_Set
{
public:
	Mspaint();
	void Command_Realize();
	~Mspaint();
};


