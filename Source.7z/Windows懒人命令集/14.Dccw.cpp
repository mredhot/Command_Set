#include "14.Dccw.h"
Dccw::Dccw()
{
}

void Dccw::Command_Realize()
{
	system("Dccw");
	system("pause");
	system("cls");
}


Dccw::~Dccw()
{
}