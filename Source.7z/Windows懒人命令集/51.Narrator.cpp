#include "51.Narrator.h"

Narrator::Narrator()
{
}

void Narrator::Command_Realize()
{
	system("narrator");
	system("pause");
	system("cls");
}


Narrator::~Narrator()
{
}