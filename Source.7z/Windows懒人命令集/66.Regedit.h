#pragma once
#include "0.Command_Set.h"

class Regedit : public Command_Set
{
public:
	Regedit();
	void Command_Realize();
	~Regedit();
};


