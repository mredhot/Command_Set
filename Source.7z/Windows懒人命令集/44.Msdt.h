#pragma once
#include "0.Command_Set.h"

class Msdt : public Command_Set
{
public:
	Msdt();
	void Command_Realize();
	~Msdt();
};


