#pragma once
#include "0.Command_Set.h"

class FXSCOVER : public Command_Set
{
public:
	FXSCOVER();
	void Command_Realize();
	~FXSCOVER();
};

