#include "67.Regedt32.h"

Regedt32::Regedt32()
{
}

void Regedt32::Command_Realize()
{
	system("regedt32");
	system("pause");
	system("cls");
}

Regedt32::~Regedt32()
{
}