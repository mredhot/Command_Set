#include "39.Mouse.h"

Mouse::Mouse()
{
}

void Mouse::Command_Realize()
{
	system("main.cpl");
	system("pause");
	system("cls");
}

Mouse::~Mouse()
{
}