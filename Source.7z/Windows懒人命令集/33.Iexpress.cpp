#include "33.Iexpress.h"

Iexpress::Iexpress()
{
}

void Iexpress::Command_Realize()
{
	system("iexpress");
	system("pause");
	system("cls");
}

Iexpress::~Iexpress()
{
}