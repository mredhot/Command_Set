#pragma once
#include "0.Command_Set.h"

class Eudcedit :public Command_Set
{
public:
	Eudcedit();
	void Command_Realize();
	~Eudcedit();
};


