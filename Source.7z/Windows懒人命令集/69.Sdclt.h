#pragma once
#include "0.Command_Set.h"

class Sdclt : public Command_Set
{
public:
	Sdclt();
	void Command_Realize();
	~Sdclt();
};


