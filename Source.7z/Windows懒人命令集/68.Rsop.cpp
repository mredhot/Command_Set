#include "68.Rsop.h"

Rsop::Rsop()
{
}

void Rsop::Command_Realize()
{
	system("rsop.msc");
	system("pause");
	system("cls");
}


Rsop::~Rsop()
{
}
