#include "61.Powercfg.h"

Powercfg::Powercfg()
{
}

void Powercfg::Command_Realize()
{
	system("powercfg.cpl");
	system("pause");
	system("cls");
}

Powercfg::~Powercfg()
{
}