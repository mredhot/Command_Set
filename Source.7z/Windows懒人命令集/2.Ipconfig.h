#pragma once
#include "0.Command_Set.h"

class Ipconfig : public Command_Set
{
public:
	Ipconfig();
	void Command_Realize();
	~Ipconfig();
};

