#include "29.Gpedit.h"

Gpedit::Gpedit()
{
}

void Gpedit::Command_Realize()
{
	system("gpedit.msc");
	system("pause");
	system("cls");
}


Gpedit::~Gpedit()
{
}