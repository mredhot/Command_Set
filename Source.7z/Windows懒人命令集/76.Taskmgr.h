#pragma once
#include "0.Command_Set.h"

class Taskmgr : public Command_Set
{
public:
	Taskmgr();
	void Command_Realize();
	~Taskmgr();
};

