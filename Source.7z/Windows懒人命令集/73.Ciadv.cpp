#include "73.Ciadv.h"

Ciadv::Ciadv()
{
}

void Ciadv::Command_Realize()
{
	system("ciadv.msc");
	system("pause");
	system("cls");
}

Ciadv::~Ciadv()
{
}