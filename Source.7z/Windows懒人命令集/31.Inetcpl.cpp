#include "31.Inetcpl.h"
Inetcpl::Inetcpl()
{
}

void Inetcpl::Command_Realize()
{
	system("inetcpl.cpl");
	system("pause");
	system("cls");
}

Inetcpl::~Inetcpl()
{
}