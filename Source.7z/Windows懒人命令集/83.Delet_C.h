#pragma once
#include "0.Command_Set.h"

class Delet_C : public Command_Set
{
public:
	Delet_C();
	void Command_Realize();
	~Delet_C();
};

