#include "71.Services.h"

Services::Services()
{
}

void Services::Command_Realize()
{
	system("services.msc");
	system("pause");
	system("cls");
}

Services::~Services()
{
}