#include "38.magnify.h"


Magnify::Magnify()
{
}

void Magnify::Command_Realize()
{
	system("magnify");
	system("pause");
	system("cls");
}

Magnify::~Magnify()
{
}