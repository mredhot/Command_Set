#include "80.Sndrec32.h"

Sndrec32::Sndrec32()
{
}
void Sndrec32::Command_Realize()
{
	system("sndrec32");
	system("pause");
	system("cls");
}

Sndrec32::~Sndrec32()
{
}