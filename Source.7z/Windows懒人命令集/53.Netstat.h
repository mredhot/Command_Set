#pragma once
#include "0.Command_Set.h"

class Netstat : public Command_Set
{
public:
	Netstat();
	void Command_Realize();
	~Netstat();
};

