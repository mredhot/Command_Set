#pragma once
#include "0.Command_Set.h"

class Shutdonw : public Command_Set
{
public:
	Shutdonw();
	void Command_Realize();
	~Shutdonw();
};

