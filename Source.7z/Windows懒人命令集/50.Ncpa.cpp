#include "50.Ncpa.h"

Ncpa::Ncpa()
{
}

void Ncpa::Command_Realize()
{
	system("ncpa.cpl");
	system("pause");
	system("cls");
}


Ncpa::~Ncpa()
{
}