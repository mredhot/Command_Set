#include "78.Winver.h"

Winver::Winver()
{
}

void Winver::Command_Realize()
{
	system("winver");
	system("pause");
	system("cls");
}

Winver::~Winver()
{
}
