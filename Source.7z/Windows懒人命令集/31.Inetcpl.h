#pragma once
#include "0.Command_Set.h"

class Inetcpl : public Command_Set
{
public:
	Inetcpl();
	void Command_Realize();
	~Inetcpl();
};


