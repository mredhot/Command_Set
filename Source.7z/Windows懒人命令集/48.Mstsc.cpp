#include "48.Mstsc.h"

Mstsc::Mstsc()
{
}

void Mstsc::Command_Realize()
{
	system("mstsc");
	system("pause");
	system("cls");
}


Mstsc::~Mstsc()
{
}
