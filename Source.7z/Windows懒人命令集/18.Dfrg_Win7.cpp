#include "18.Dfrg_Win7.h"

Dfrg_Win7::Dfrg_Win7()
{
}

void Dfrg_Win7::Command_Realize()
{
	system("dfrg.msc");
	system("pause");
	system("cls");
}

Dfrg_Win7::~Dfrg_Win7()
{
}