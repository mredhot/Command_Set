#include "77.Packager.h"

Packager::Packager()
{
}
void Packager::Command_Realize()
{
	system("packager");
	system("pause");
	system("cls");
}



Packager::~Packager()
{
}