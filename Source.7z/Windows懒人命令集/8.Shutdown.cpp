#include "8.Shutdown.h"


Shutdonw::Shutdonw()
{
}
void Shutdonw::Command_Realize()
{
	system("shutdown -s -t 00");
	system("pause");
	system("cls");
}


Shutdonw::~Shutdonw()
{
}