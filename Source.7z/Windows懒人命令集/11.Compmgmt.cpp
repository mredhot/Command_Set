#include "11.Compmgmt.h"


Compmgmt::Compmgmt()
{
}

void Compmgmt::Command_Realize()
{
	system("compmgmt.msc");
	system("pause");
	system("cls");
}

Compmgmt::~Compmgmt()
{
}