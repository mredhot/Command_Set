#pragma once
#include "0.Command_Set.h"

class OptionalFeatures : public Command_Set
{
public:
	OptionalFeatures();
	void Command_Realize();
	~OptionalFeatures();
};


