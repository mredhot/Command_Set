#pragma once
#include "0.Command_Set.h"

class Colorcpl : public Command_Set
{
public:
	Colorcpl();
	void Command_Realize();
	~Colorcpl();
};


