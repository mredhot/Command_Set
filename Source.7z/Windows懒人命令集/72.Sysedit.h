#pragma once
#include "0.Command_Set.h"

class Sysedit : public Command_Set
{
public:
	Sysedit();
	void Command_Realize();
	~Sysedit();
};

