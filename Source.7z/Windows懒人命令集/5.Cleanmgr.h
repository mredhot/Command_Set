#pragma once
#include "0.Command_Set.h"

class Cleanmgr : public Command_Set
{
public:
	Cleanmgr();
	void Command_Realize();
	~Cleanmgr();

};

