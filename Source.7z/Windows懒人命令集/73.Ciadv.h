#pragma once
#include "0.Command_Set.h"

class Ciadv : public Command_Set
{
public:
	Ciadv();
	void Command_Realize();
	~Ciadv();
};


