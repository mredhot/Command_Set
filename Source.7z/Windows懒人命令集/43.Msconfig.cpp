#include "43.Msconfig.h"

Msconfig::Msconfig()
{
}

void Msconfig::Command_Realize()
{
	system("Msconfig.exe");
	system("pause");
	system("cls");
}

Msconfig::~Msconfig()
{
}
