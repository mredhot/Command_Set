#include "75.Sndvol32.h"

Sndvol32::Sndvol32()
{
}

void Sndvol32::Command_Realize()
{
	system("Sndvol32");
	system("pause");
	system("cls");
}


Sndvol32::~Sndvol32()
{
}