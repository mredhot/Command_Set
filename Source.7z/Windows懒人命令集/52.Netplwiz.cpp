#include "52.Netplwiz.h"


Netplwiz::Netplwiz()
{
}

void Netplwiz::Command_Realize()
{
	system("Netplwiz");
	system("pause");
	system("cls");
}

Netplwiz::~Netplwiz()
{
}