#pragma once
#include "0.Command_Set.h"

class Hdwwiz : public Command_Set
{
public:
	Hdwwiz();
	void Command_Realize();
	~Hdwwiz();
};

