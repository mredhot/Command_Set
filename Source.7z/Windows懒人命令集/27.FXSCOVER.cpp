#include "27.FXSCOVER.h"

FXSCOVER::FXSCOVER()
{
}

void FXSCOVER::Command_Realize()
{
	system("fxscover");
	system("pause");
	system("cls");
}


FXSCOVER::~FXSCOVER()
{
}