#pragma once
#include "0.Command_Set.h"

class Mstsc : public Command_Set
{
public:
	Mstsc();
	void Command_Realize();
	~Mstsc();
};

