#include "25.Explorer.h"

Explorer::Explorer()
{
}
void Explorer::Command_Realize()
{
	system("explorer");
	system("pause");
	system("cls");
}

Explorer::~Explorer()
{
}