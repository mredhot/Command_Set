#include "69.Sdclt.h"

Sdclt::Sdclt()
{
}

void Sdclt::Command_Realize()
{
	system("sdclt");
	system("pause");
	system("cls");
}

Sdclt::~Sdclt()
{
}