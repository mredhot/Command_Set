#include "20.Diskmgmt.h"

Diskmgmt::Diskmgmt()
{
}

void Diskmgmt::Command_Realize()
{
	system("diskmgmt.msc");
	system("pause");
	system("cls");
}

Diskmgmt::~Diskmgmt()
{
}