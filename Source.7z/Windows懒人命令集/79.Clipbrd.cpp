#include "79.Clipbrd.h"

Clipbrd::Clipbrd()
{
}

void Clipbrd::Command_Realize()
{
	system("Clipbrd");
	system("pause");
	system("cls");
}

Clipbrd::~Clipbrd()
{
}