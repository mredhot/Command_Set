#pragma once
#include "0.Command_Set.h"

class Sndvol32 : public Command_Set
{
public:
	Sndvol32();
	void Command_Realize();
	~Sndvol32();
};


