#pragma once
#include "0.Command_Set.h"

class Resmon : public Command_Set
{
public:
	Resmon();
	void Command_Realize();
	~Resmon();
};


