#pragma once
#include "0.Command_Set.h"

class Desk_Cpl : public Command_Set
{
public:
	Desk_Cpl();
	void Command_Realize();
	~Desk_Cpl();
};

