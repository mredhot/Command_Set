#include "34.Joy.h"

Joy::Joy()
{
}

void Joy::Command_Realize()
{
	system("joy.cpl");
	system("pause");
	system("cls");
}

Joy::~Joy()
{
}