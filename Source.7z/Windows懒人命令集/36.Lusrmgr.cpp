#include "36.Lusrmgr.h"

Lusrmgr::Lusrmgr()
{
}

void Lusrmgr::Command_Realize()
{
	system("lusrmgr.msc");
	system("pause");
	system("cls");
}

Lusrmgr::~Lusrmgr()
{
}