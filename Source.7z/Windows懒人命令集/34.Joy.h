#pragma once
#include "0.Command_Set.h"

class Joy : public Command_Set
{
public:
	Joy();
	void Command_Realize();
	~Joy();
};


