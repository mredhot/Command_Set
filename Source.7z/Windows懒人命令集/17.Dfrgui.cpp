#include "17.Dfrgui.h"

Dfrgui::Dfrgui()
{
}

void Dfrgui::Command_Realize()
{
	system("dfrgui");
	system("pause");
	system("cls");
}

Dfrgui::~Dfrgui()
{
}